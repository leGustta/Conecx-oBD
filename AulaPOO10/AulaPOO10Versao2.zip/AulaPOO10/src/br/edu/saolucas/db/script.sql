DROP TABLE veiculos;

CREATE TABLE veiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chassis VARCHAR(50) NOT NULL,
    placa VARCHAR(10) NOT NULL
);

SELECT * FROM veiculos;





