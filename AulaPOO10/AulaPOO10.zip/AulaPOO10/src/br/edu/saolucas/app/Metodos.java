package br.edu.saolucas.app;

public class Metodos {
	
	public static float somaNumeros(float valor1, float valor2) {
		return valor1 + valor2;
	}

	public static float subtrairNumeros(float valor1, float valor2) {
		return valor1 - valor2;
	}
	
	public static float multiplicarNumeros(float valor1, float valor2) {
		return valor1 * valor2;
	}
	
	public static float dividirNumeros(float valor1, float valor2) {
		return valor1 / valor2;
	}
}
