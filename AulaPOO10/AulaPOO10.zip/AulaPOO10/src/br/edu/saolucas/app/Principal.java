package br.edu.saolucas.app;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.edu.saolucas.db.ConexaoDB;

public class Principal {

	public static void main(String[] args) {
		ConexaoDB.getInstancia();
		Connection conexao = ConexaoDB.conexao;
		
	}

}











//		ConexaoDB.getInstancia();

//		Connection conexao = ConexaoDB.conexao; 